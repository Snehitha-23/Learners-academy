package com.learner.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.Class.Class;
import com.Class.Student;
import com.Class.Subject;
import com.Class.Teacher;
import com.learner.exception.BusinessException;

public interface LearnerDao {
	public Map<Class, ArrayList<String>> allSubjects()throws BusinessException;
	public Map<Class, ArrayList<String>> allTeachers()throws BusinessException;
	public List<String> allClasses()throws BusinessException;
	public Map<Class, ArrayList<String>> allStudents()throws BusinessException;
	public List<String> classReport(String classname) throws BusinessException;
}
