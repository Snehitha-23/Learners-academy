package com.learner.dao.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.Class.Class;
import com.Class.Student;
import com.Class.Subject;
import com.Class.Teacher;
import com.learner.dao.LearnerDao;
import com.learner.exception.BusinessException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class LearnerDaoImpl implements LearnerDao {
	Configuration configuration = new Configuration().configure();
	StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
			.applySettings(configuration.getProperties());
	SessionFactory factory=configuration.buildSessionFactory(builder.build());
	
	@Override
	public Map<Class,ArrayList<String>> allSubjects() throws BusinessException {
		Session session=factory.openSession();
		  Query query= session.createQuery("from com.Class.Subject");
			List<Subject> subjectList= query.list();
			Map<Class,ArrayList<String>> hm = new HashMap<Class,ArrayList<String>>();
			for(Subject subject:subjectList) {

				ArrayList<String>j=new ArrayList<String>();
				if(hm.get(subject.getClassname())==null) {
					j.add("SUBJECTNAME:"+subject.getSubjectName()); 
						  hm.put(subject.getClassname(),j);
				}
				else {
					j=hm.get(subject.getClassname());
		     		j.add(subject.getSubjectName());
	                hm.put(subject.getClassname(),j);
	                 } 
			}
			
		return hm;
		}

	@Override
	public Map<Class,ArrayList<String>> allTeachers() throws BusinessException {
		Session session=factory.openSession();
		Query query=session.createQuery("from com.Class.Teacher");
		  List<Teacher> teacherList= query.list();
		Map<Class,ArrayList<String>> hm = new HashMap<Class,ArrayList<String>>();
		for(Teacher teacher:teacherList) {

			ArrayList<String>j=new ArrayList<String>();
			if(hm.get(teacher.getClassname())==null) {
				j.add(teacher.getTeacherName()); 
					  hm.put(teacher.getClassname(),j);
			}
			else {
				j=hm.get(teacher.getClassname());
	     		j.add(teacher.getTeacherName());
            hm.put(teacher.getClassname(),j);
            
             } 
		}
		return hm;
		
	}

	@Override
	public List<String> allClasses() throws BusinessException {
		Session session=factory.openSession();
		Query query=session.createQuery("from com.Class.Class");
		List<Class>classList=query.list();
		List<String>allclasses=new ArrayList<String>();
		for(Class classes:classList) {
			
			allclasses.add(classes.getClassname());
			}

	
			
		return allclasses;
		
	}

	@Override
	public Map<Class,ArrayList<String>> allStudents() throws BusinessException {
		Session session=factory.openSession();
		Query query=session.createQuery("from com.Class.Student");
		List<Student>studentList=query.list();
		Map<Class,ArrayList<String>> hm = new HashMap<Class,ArrayList<String>>();
		for(Student student:studentList) {

			ArrayList<String>j=new ArrayList<String>();
			if(hm.get(student.getClassName())==null) {
				j.add(student.getStudentName()+"  "+"studentid:"+student.getStudentId()); 
					  hm.put(student.getClassName(),j);
			}
			else {
				j=hm.get(student.getClassName());
	     		j.add(student.getStudentName()+"   "+"studentid:"+student.getStudentId());
            hm.put(student.getClassName(),j);
            
             } 
		}
		
		
		return hm;
	}

	@Override
	public List<String>classReport(String classname) throws BusinessException {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery(" from com.Class.Class");
		List<Class>classList=query.list();
		List<String>j=new ArrayList<String>();
		for(Class classreport:classList) {

			if(classreport.getClassname().equals(classname))
			{
		 		j.add(classreport.getTotalNoOfStudents()+"  "+classreport.getNoOfSubjects()+" "+classreport.getTotalNoOfTeachers()); 
		    
		     } 
			
		}
		transaction.commit();
		return j;
		
	}
	
}	
		
		
		
		

