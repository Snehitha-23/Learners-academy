package com.learner.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.Class.Class;
import com.Class.Student;
import com.Class.Subject;
import com.Class.Teacher;
import com.learner.dao.LearnerDao;
import com.learner.dao.Impl.LearnerDaoImpl;
import com.learner.exception.BusinessException;
import com.learner.service.LearnerService;


public class LearnerServiceImpl implements LearnerService{
	private LearnerDao learnerDao=new LearnerDaoImpl();
	@Override
	public Map<Class, ArrayList<String>> allSubjects() throws BusinessException {
		
		return learnerDao.allSubjects();
	}

	@Override
	public Map<Class, ArrayList<String>> allTeachers() throws BusinessException {
		// TODO Auto-generated method stub
		return learnerDao.allTeachers();
	}

	@Override
	public List<String> allClasses() throws BusinessException {
		// TODO Auto-generated method stub
		return learnerDao.allClasses();
	}

	@Override
	public Map<Class, ArrayList<String>> allStudents() throws BusinessException {
		// TODO Auto-generated method stub
		return learnerDao.allStudents();
	}

	@Override
	public List<String>classReport(String classname) throws BusinessException {
		// TODO Auto-generated method stub
		return learnerDao.classReport(classname);
	}

}
