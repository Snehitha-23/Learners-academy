package com.learner.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.Class.Class;
import com.Class.Subject;
import com.learner.exception.BusinessException;
import com.learner.service.LearnerService;
import com.learner.service.Impl.LearnerServiceImpl;


@Path("/learner")
public class LearnerController {
private LearnerService service=new LearnerServiceImpl();
@Path("/allSubjects")
@GET
@Produces(MediaType.APPLICATION_JSON)
	public Map<Class, ArrayList<String>> allSubjects(){
		try {
			return service.allSubjects();
		} catch (BusinessException e) {
			System.out.println(e);
	} 
		return null;
	
}	
@Path("/allTeachers")
@GET
@Produces(MediaType.APPLICATION_JSON)
	public Map<Class, ArrayList<String>> allTeachers(){
		try {
			return service.allTeachers();
		} catch (BusinessException e) {
			System.out.println(e);
	}
		return null;
	
}

@Path("/allClasses")
@GET
@Produces(MediaType.APPLICATION_JSON)
	public List<String> allClasses(){
		try {
			return service.allClasses();
		} catch (BusinessException e) {
			System.out.println(e);
	}
		return null;
	
}

@Path("/allStudents")
@GET
@Produces(MediaType.APPLICATION_JSON)
	public Map<Class, ArrayList<String>> allStudents(){
		try {
			return service.allStudents();
		} catch (BusinessException e) {
			System.out.println(e);
	}
		return null;
	
}
@Path("/ClassReport/{classname}")
@GET
@Produces(MediaType.APPLICATION_JSON)
public List<String>classReport(@PathParam("classname")String classname){
	try {
		return service.classReport(classname);
	} catch (BusinessException e) {
		System.out.println(e);
		return null;
	}
}
}
