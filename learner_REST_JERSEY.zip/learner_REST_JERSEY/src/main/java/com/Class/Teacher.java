package com.Class;

import java.util.ArrayList;
import java.util.List;
import com.Class.Subject;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table
public class Teacher {
@Override
	public String toString() {
		return "Teacher [teacherId=" + teacherId + ", teacherName=" + teacherName 
				+ ", subjectsList=" + subjectsList + "]";
	}
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int teacherId;

private String teacherName;
	
@ManyToOne
@JoinColumn(name="teacher_classname")
private Class classname;

@OneToMany(mappedBy="teacherName")
private List<Subject>subjectsList=new ArrayList<>();


public Class getClassname() {
	return classname;
}
public void setClassname(Class classname) {
	this.classname = classname;
}
public Teacher() {
	super();
	
}
public int getTeacherId() {
	return teacherId;
}
public void setTeacherId(int teacherId) {
	this.teacherId = teacherId;
}
public Teacher(String teacherName) {
	super();
	this.teacherName = teacherName;
}
public Teacher(String teacherName, List<Subject> subjectsList) {
		super();
		this.teacherName = teacherName;
		this.subjectsList = subjectsList;
}











public String getTeacherName() {
	return teacherName;
}
public void setTeacherName(String teacherName) {
	this.teacherName = teacherName;
}
public List<Subject> getSubjectsList() {
	return subjectsList;
}
public void setSubjectsList(List<Subject> subjectsList) {
	this.subjectsList = subjectsList;
}

}
