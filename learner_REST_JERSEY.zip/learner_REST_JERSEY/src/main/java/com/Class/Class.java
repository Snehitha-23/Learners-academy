package com.Class;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Class {
@Id
private String classname;


@OneToMany(mappedBy="className")
private List<Student>TotalNoOfStudents=new ArrayList<>();
@OneToMany(mappedBy="classname")
private List<Subject>noOfSubjects=new ArrayList<>();
@OneToMany(mappedBy="classname")
private List<Teacher>TotalNoOfTeachers=new ArrayList<>();

public List<Subject> getNoOfSubjects() {
	return noOfSubjects;
}
public void setNoOfSubjects(List<Subject> noOfSubjects) {
	this.noOfSubjects = noOfSubjects;
}

@Override
public String toString() {
	return  classname;
}
public Class() {
	super();
}
public List<Teacher> getTotalNoOfTeachers() {
	return TotalNoOfTeachers;
}
public void setTotalNoOfTeachers(List<Teacher> totalNoOfTeachers) {
	TotalNoOfTeachers = totalNoOfTeachers;
}
public Class(String classname, List<Student> totalNoOfStudents, List<Subject> noOfSubjects, List<Teacher> totalNoOfTeachers) {
	super();
	this.classname = classname;
	TotalNoOfStudents = totalNoOfStudents;
	this.noOfSubjects = noOfSubjects;
	TotalNoOfTeachers = totalNoOfTeachers;
}
public Class(String classname, List<Student> totalNoOfStudents, List<Subject>noOfSubjects) {
	super();
	this.classname = classname;
	TotalNoOfStudents = totalNoOfStudents;
	this.noOfSubjects = noOfSubjects;
}
public String getClassname() {
	return classname;
}
public void setClassname(String classname) {
	this.classname = classname;
}
public List<Student> getTotalNoOfStudents() {
	return TotalNoOfStudents;
}
public void setTotalNoOfStudents(List<Student> totalNoOfStudents) {
	TotalNoOfStudents = totalNoOfStudents;
}

public Class(String classname) {
	super();
	this.classname = classname;
}

}