package com.Class;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table
public class Student implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int studentId;

   private String studentName;
   
   @ManyToOne
   @JoinColumn(name="student_className")
   private  Class className;
   public Student() {
		super();
		
	} 
   

   
  
@Override
public String toString() {
	return "Student [studentId=" + studentId + ", studentName=" + studentName + "]";
}


public int getStudentId() {
	return studentId;
}


public void setStudentId(int studentId) {
	this.studentId = studentId;
}


public Student(String studentName) {
	super();
	this.studentName = studentName;
}
public Class getClassName() {
	return className;
}


public void setClassName(Class className) {
	this.className = className;
}


public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}

		
}
