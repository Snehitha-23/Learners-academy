package com.Class;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Subject {
@Override
	public String toString() {
		return "Subject [subjectId=" + subjectId + ", subjectName=" + subjectName +"]";
	}
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int subjectId;
private String subjectName;

@ManyToOne
@JoinColumn(name="subject_teacherName")
private Teacher teacherName;

@ManyToOne
@JoinColumn(name="subject_className")
private Class classname;


public String getSubjectName() {
	return subjectName;
}


public Teacher getTeacherName() {
	return teacherName;
}

public void setTeacherName(Teacher teacherName) {
	this.teacherName = teacherName;
}

public  Class getClassname() {
	return classname;
}

public void setClassname(Class classname) {
	this.classname = classname;
}

public void setSubjectName(String subjectName) {
	this.subjectName = subjectName;
}
public Subject(String subjectName) {
	super();
	this.subjectName = subjectName;
}
public Subject() {
	
}

}




